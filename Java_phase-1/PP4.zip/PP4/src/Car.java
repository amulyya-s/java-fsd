public class Car {
    private String make;
    private String model;
    private int year;

    // Default constructor
    public Car() {
        make = "Unknown";
        model = "Unknown";
        year = 0;
    }

    // No-args constructor
    public Car(String make, String model, int year) {
        this.make = make;
        this.model = model;
        this.year = year;
    }

    // Parameterized constructor
    public Car(String make, String model) {
        this.make = make;
        this.model = model;
        year = 0;
    }

    public void display() {
        System.out.println("Make: " + make);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }

    public static void main(String[] args) {
        // Create a car using the default constructor
        Car car1 = new Car();
        car1.display();

        // Create a car using the no-args constructor
        Car car2 = new Car("Toyota", "Corolla", 2019);
        car2.display();

        // Create a car using the parameterized constructor
        Car car3 = new Car("Ford", "Mustang");
        car3.display();
    }
}