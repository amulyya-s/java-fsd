public class Arrays {

public static void main(String[] args) {

//single-dimensional array
int a[]= {21,34,76,89,02};
for(int i=0;i<5;i++) {
System.out.println("Elements of array a: "+a[i]);
}


//multidimensional array
int[][] b = {
            {12, 45, 64, 89}, 
            {30, 16, 49} };
      
      System.out.println("\nLength of row 1: " + b[0].length);
      }
}