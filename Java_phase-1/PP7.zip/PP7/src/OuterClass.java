public class OuterClass {
    private int outerField;

    public OuterClass(int outerField) {
        this.outerField = outerField;
    }

    public void outerMethod() {
        InnerClass inner = new InnerClass();
        inner.innerMethod();
    }

    public class InnerClass {
        private int innerField;

        public InnerClass() {
            this.innerField = 12;
        }

        public void innerMethod() {
            System.out.println("Inner field: " + innerField);
            System.out.println("Outer field: " + outerField);
        }
    }

    public static void main(String[] args) {
        OuterClass outer = new OuterClass(70);
        outer.outerMethod();
    }
}