
public class accessspecifiers {
public static void main(String[] args) {
	
      
        Person person = new Person();
        
    
        person.name = "Alley";
        System.out.println("Name: " + person.name);
        person.walk();
        
        // Access protected variables and methods
        person.age = 90;
        System.out.println("Age: " + person.age);
        person.talk();
        
    }
}

class Person {
    public String name;
    protected int age;
    private int salary;
    
    public void walk() {
        System.out.println("Viewing...");
    }
    
    protected void talk() {
        System.out.println("Talking...");
    }
    
    private void think() {
        System.out.println("Thinking...");
    }
}
