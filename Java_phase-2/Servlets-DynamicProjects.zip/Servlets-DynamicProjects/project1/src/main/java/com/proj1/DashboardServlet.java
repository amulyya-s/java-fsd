package com.proj1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DashboardServlet
 */
public class DashboardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DashboardServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests (if needed)
        doPost(request, response);
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String username= (String) session.getAttribute("username");
		
		session.setAttribute("username", username);
		if(username != null) {
			out.println("<html><body style='text-align:center'>"
					+ "<h2 style='color:red'>Welcome to Dashboard<h2>"
					+ "<br><br>"
					+ username.substring(0, username.indexOf('@')).toUpperCase()
					+"<br><br>"
					+ "<a href='LogoutServlet'>Logout</a>"
					+ "</body></html>");
		}else {
			response.sendRedirect("LoginServlet");
		}
		
	}
	}
